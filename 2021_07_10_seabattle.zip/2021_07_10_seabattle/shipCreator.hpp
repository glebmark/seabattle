//
//  shipCreator.hpp
//  2021_07_10_seabattle
//
//  Created by Gleb Markin on 10.07.2021.
//

#ifndef shipCreator_hpp
#define shipCreator_hpp

#include <stdio.h>
void ships (char *typedKey, int shipSize);

#endif /* shipCreator_hpp */
