//
//  main.cpp
//  2021_07_10_seabattle
//
//  Created by Gleb Markin on 10.07.2021.
//

#include <iostream>
#include "grid.hpp"

int main(int argc, const char * argv[]) {
	cycle(); // run main cycle
	return 0;
}
