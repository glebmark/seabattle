//
//  service.hpp
//  2021_07_10_seabattle
//
//  Created by Gleb Markin on 10.07.2021.
//

#ifndef service_hpp
#define service_hpp

#include <stdio.h>

char* getStr( char* buffer , int maxRead );
void ClearScreen();

#endif /* service_hpp */
